from pymongo import MongoClient
def get_database():
 
   # Provide the mongodb atlas url to connect python to mongodb using pymongo
   #CONNECTION_STRING = "mongodb+srv://user:pass@cluster.mongodb.net/myFirstDatabase"
   CONNECTION_STRING = "mongodb://bhakmadarchod789:VMJfVD3h7iBbw2TF@cluster0.453ry6n.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
 
   # Create a connection using MongoClient. You can import MongoClient or use pymongo.MongoClient
   client = MongoClient(CONNECTION_STRING)
 
   # Create the database for our example (we will use the same database throughout the tutorial
   return client['nadeemabnamrodb']
  
# This is added so that many files can reuse the function get_database()
if __name__ == "__main__":   
  
   # Get the database
    dbname = get_database()
    collection_name = dbname["abnamrodata"]
    item_1 = {
    "_id" : "U1IT00001"
    }
    item_2 = {
    "_id" : "U1IT00002"
    }
    collection_name.insert_many([item_1,item_2])
