from pymongo import MongoClient
#def get_db_handle(db_name, host, port, username, password):
def get_db_handle(host):
    #client = MongoClient(host=host,port=int(port),username='bhakmadarchod789',password='VMJfVD3h7iBbw2TF')
    client = MongoClient(host)
    #db_handle = client[db_name]
#    db_handle.insert_one({"name":"nadeem"})
    collection = db_handle['abnamrodata']
    collection.insert_one({"hello":"world"})
    print(results)
    print("test over")
    return db_handle, client


if __name__ == "__main__":
    host = "mongodb+srv://bhakmadarchod789:VMJfVD3h7iBbw2TF@cluster0.453ry6n.mongodb.net/nadeemabnamrodb?retryWrites=true&w=majority&appName=Cluster0"
    username = 'bhakmadarchod789'
    password = 'VMJfVD3h7iBbw2TF'
    port = 27017
    #get_db_handle('nadeemabnamrodb', host, port, username=username, password=password)
    get_db_handle(host)
