from django import forms


class DataQueryForm(forms.Form):
    query_name= forms.CharField(label="For sample data,just type sample", max_length=10)
