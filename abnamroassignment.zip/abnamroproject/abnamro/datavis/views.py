from django.shortcuts import render
from django.http import JsonResponse , FileResponse, HttpResponse

# Create your views here.

def homesweethome(requests):
    #return HttpResponse("Hello wolld")
    #return HttpResponse("home.html)
    #form = geeksmodel()
    #return JsonResponse({"key": "value"})
    
    jsondata = {
            "data":[
    
    {
    "name":"A",
    "description":"This is a description of A",
    "parent":""
    },
    {
    "name":"B",
    "description":"This is a description of B",
    "parent":"A"
    },
    {
    "name":"C",
    "description":"This is a description of C",
    "parent":"A"
    },
    {
    "name":"D",
    "description":"This is a description of D",
    "parent":"A"
    },
    {
    "name":"B-1",
    "description":"This is a description of B-1",
    "parent":"B"
    },
    {
    "name":"B-2",
    "description":"This is a description of B-2",
    "parent":"B"
    },
    {
    "name":"B-3",
    "description":"This is a description of B-3",
    "parent":"B"
    },
    ],
    }
    
    if requests.method == "GET":
        form = DataQueryForm(requests.GET)
        if form.is_valid():
    #return JsonResponse(jsondata)
    #return render(requests, "home.html",{"jsoninfo":jsondata})
            return render(requests, "index.html",{"jsoninfo":jsondata})
    
    form = DataQueryForm()
    return render(requests, "dataquery.html", {"form": form})

    #response = FileResponse(open("./datafile.json", "rb"))
    #return render(requests, "index.html",{"jsoninfo":response})




def displayjsonid(requests, objid):
    #return httpResponse("home.html")
    mystr = "<html>Nothing here</html>"
    return HttpResponse(mystr)

from .forms import DataQueryForm


def welcometodatavis(requests):
    return render(requests, "dataquery.html")
    #return HttpResponse("home.html")




from django.http import HttpResponseRedirect
from django.shortcuts import render

from .forms import DataQueryForm 


def get_name(requests):
    print("---entered inside get_name--- 111")
    # if this is a POST request we need to process the form data
    if requests.method == "GET":
        print("---entered inside get_name--- 222")
        # create a form instance and populate it with data from the request:
        form = DataQueryForm(requests.GET)
        print("---entered inside get_name--- 333")
        # check whether it's valid:
        print(form.errors)
        if form.is_valid():
            print("---entered inside get_name--- 333")
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            homesweethome(requests)
            #return HttpResponseRedirect("/thanks/")

    # if a GET (or any other method) we'll create a blank form
    else:
        form = DataQueryForm()

    return render(requests, "dataquery.html", {"form": form})
