from django.urls import path
from . import views

urlpatterns = [
    # ex: /polls/
    path("", views.welcometodatavis, name="welcometodatavis"),
    path("hello/", views.homesweethome, name="homesweethome"),
    path("<int:objid>/", views.displayjsonid),
    path("query-name/", views.homesweethome, name="homesweethome"),
    ]
