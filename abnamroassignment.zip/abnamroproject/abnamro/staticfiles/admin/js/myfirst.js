// Define the COVID-19 data
const dataoneee = {
    name: 'Global',
    children: [
      {
        name: 'Europe',
        value: 12,
        type: 'blue',
        level: 'aqua',
        children: [
          {
            name: 'Germany',
            value: 9,
            type: 'red',
            level: '#863a9f',
            children: [
              {
                name: 'Cumulative Confirmed Cases - 150000',
                value: 9,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Cumulative Deceased - 1000',
                value: 9,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Total Recoveries - 140000',
                value: 9,
                type: '#863a9f',
                level: '#3a9f7e',
              },
            ],
          },
          {
            name: 'France',
            value: 7,
            type: 'red',
            level: '#863a9f',
            children: [
              {
                name: 'Cumulative Confirmed Cases - 120000',
                value: 7,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Cumulative Deceased - 2000',
                value: 7,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Total Recoveries - 100000',
                value: 7,
                type: '#863a9f',
                level: '#3a9f7e',
              },
            ],
          },
        ],
      },
      {
        name: 'North America',
        value: 10,
        type: 'blue',
        level: 'aqua',
        children: [
          {
            name: 'USA',
            value: 8,
            type: 'red',
            level: '#863a9f',
            children: [
              {
                name: 'Cumulative Confirmed Cases - 500000',
                value: 8,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Cumulative Deceased - 10000',
                value: 8,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Total Recoveries - 400000',
                value: 8,
                type: '#863a9f',
                level: '#3a9f7e',
              },
            ],
          },
          {
            name: 'Canada',
            value: 2,
            type: 'red',
            level: '#863a9f',
            children: [
              {
                name: 'Cumulative Confirmed Cases - 80000',
                value: 2,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Cumulative Deceased - 3000',
                value: 2,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Total Recoveries - 60000',
                value: 2,
                type: '#863a9f',
                level: '#3a9f7e',
              },
            ],
          },
        ],
      },
      {
        name: 'Africa',
        value: 8,
        type: 'blue',
        level: 'aqua',
        children: [
          {
            name: 'Nigeria',
            value: 4,
            type: 'red',
            level: '#863a9f',
            children: [
              {
                name: 'Cumulative Confirmed Cases - 50000',
                value: 4,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Cumulative Deceased - 1000',
                value: 4,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Total Recoveries - 45000',
                value: 4,
                type: '#863a9f',
                level: '#3a9f7e',
              },
            ],
          },
          {
            name: 'South Africa',
            value: 4,
            type: 'red',
            level: '#863a9f',
            children: [
              {
                name: 'Cumulative Confirmed Cases - 200000',
                value: 4,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Cumulative Deceased - 5000',
                value: 4,
                type: '#863a9f',
                level: '#3a9f7e',
              },
              {
                name: 'Total Recoveries - 150000',
                value: 4,
                type: '#863a9f',
                level: '#3a9f7e',
              },
            ],
          },
        ],
      },
    ],
  };
  
const mydatatest= {
"data":[
{
"name":"A",
"description":"This is a description of A",
"parent":""
},
{
"name":"B",
"description":"This is a description of B",
"parent":"A"
},
{
"name":"C",
"description":"This is a description of C",
"parent":"A"
},
{
"name":"D",
"description":"This is a description of D",
"parent":"A"
},
{
"name":"B-1",
"description":"This is a description of B-1",
"parent":"B"
},
{
"name":"B-2",
"description":"This is a description of B-2",
"parent":"B"
},
{
"name":"B-3",
"description":"This is a description of B-3",
"parent":"B"
},
],
};



  //data = d3.json(mydata)//.then(function(data) {
    // Create a tree layout
    const tree = d3.tree()
      .size([500, 400]);

    // Create a hierarchical structure from the data
    const root = d3.hierarchy(mydata);
    console.log(root)

    // Assigns the x and y position for the nodes
    const treeData = tree(root);

    // Add links between the nodes
    const svg = d3.select("svg")
      .attr("width", 900)
      .attr("height", 600)
      .append("g")
      .attr("transform", "translate(40,0)");

    // Define the links
    const link = svg.selectAll("path.link")
      .data(treeData.links())
      .enter().append("path")
      .attr("class", "link")
      .attr("d", d3.linkHorizontal()
        .x(function(d) { return d.y; })
        .y(function(d) { return d.x; }));

    // Define the nodes
    const node = svg.selectAll("g.node")
      .data(treeData.descendants())
      .enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) {
        return "translate(" + d.y + "," + d.x + ")";
      });

    // Add circles to the nodes
    node.append("circle")
      .attr("r", 10)
      .style("fill", "#fff");

      console.log(node);
    // Add labels to the nodes
    node.append("text")
      .attr("dy", ".35em")
      .attr("x", function(d) { return d.children ? -13 : 13; })
      .style("text-anchor", function(d) {
        return d.children ? "end" : "start";
      })
      .text(function(d) { return d.data.name; });


  // Select the SVG container
//  const svg = d3.select("svg");

  // Append a rectangle to the SVG
 
  // You can add more attributes or styles as needed


     //console.log(d); 
    // Function to handle click on nodes
//    function click(d) {

//      console.log(d.data.name);
      //alert("Clicked on node: " + d.data.description);
//    }

    // Add click event listener to nodes
    //node.on("click", click);
    node.on("click", function(event, d) {
      
      console.log("eneterd");
      let str1 = d.data.name + '\n' + d.data.description + '\n' + d.data.parent;

      const x = d.y + 40; // Adjust as needed
      const y = d.x - 20; // Adjust as needed

      //const x = 20; // Adjust as needed
      //const y = 20; // Adjust as needed

      // Remove any existing pop-up
      svg.selectAll(".popup").remove();
  
      // Create pop-up
      const popup = svg.append("g")
        .attr("class", "popup")
        .attr("transform", `translate(${x},${y})`);
  
      popup.append("rect")
        .attr("width", 300)
        .attr("height", 80)
        //.attr("rx", 10)
        //.attr("ry", 10)
        .attr("fill", "white")
        .attr("stroke", "steelblue")
        .attr("stroke-width", 2);

        popup.append("text")
        .attr("x", 280)
        .attr("y", 10)
        .attr("dy", "0.3em")
        .attr("text-anchor", "middle")
        .text('X')
        .on("click", () => popup.remove());
  
      popup.append("text")
        .attr("x", 0)
        .attr("y", 10)
        .attr("dy", "0.3em")
        .attr("text-anchor", "start")
        .text(`Name: ${d.data.name}`)

        popup.append("text")
        .attr("x", 0)
        .attr("y", 25)
        .attr("dy", "0.3em")
        .attr("text-anchor", "start")
        .text(`Parent: ${d.data.parent}`)
        popup.append("text")
        .attr("x", 0)
        .attr("y", 40)
        .attr("dy", "0.3em")
        .attr("text-anchor", "start")
        .text(`Description: ${d.data.description}`)

//        popup.append("text")
//      .attr("x", x + 140)
//      .attr("y", y + 20)
//      .attr("text-anchor", "middle")
//      .style("cursor", "pointer")
//      .attr("font-size", "21px")
        


 

//       .text(`value: ${d.data.parent}\n`)
//       .text(`Name: ${d.data.name}\n`);
  
      //popup.append("text")
        //.attr("x", 60)
        //.attr("y", 40)
        //.attr("dy", "0.3em")
        //.attr("text-anchor", "middle")
        //.text(`Parent: ${d.data.parent}`);

        //popup.append("text")
        //.attr("x", 60)
        //.attr("y", 40)
        //.attr("dy", "0.3em")
        //.attr("text-anchor", "middle")
        //.text(`Description: ${d.data.description}`);

      //alert(d.data.name + d.data.description + d.data.parent)
      
      console.log(d.data.name + d.data.description + d.data.parent)
    });



